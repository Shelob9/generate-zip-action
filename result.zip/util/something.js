module.exports = 'something';
